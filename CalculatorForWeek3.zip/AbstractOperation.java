package CalculatorForWeek3;

public abstract class AbstractOperation {
    public abstract double operate(int num1, int num2);
}
