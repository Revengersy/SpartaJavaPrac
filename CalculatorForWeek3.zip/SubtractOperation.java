package CalculatorForWeek3;

public class SubtractOperation extends AbstractOperation {
    @Override
    public double operate(int num1, int num2) {
        return num1 - num2;
    }
}