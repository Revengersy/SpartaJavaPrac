package Calculators.level.three;

public enum CalculationType {
    PLUS,
    MINUS,
    MULTIPLY,
    DIVIDE;
}
